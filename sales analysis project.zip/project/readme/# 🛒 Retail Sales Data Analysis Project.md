# 🛒 Retail Sales Data Analysis Project

This project explores a fictional superstore sales dataset to gain insights on product performance, profits, and regional trends.

## Features
- Monthly trend analysis
- Top products by sales
- Profit by category
- Regional sales distribution

## Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn
- Jupyter Notebook

## To Run
```bash
pip install -r requirements.txt
jupyter notebook sales_analysis.ipynb

3. Save it as `README.md` in the project folder.

---

## ✅ 4. **Create `requirements.txt`**

1. Open your terminal/command prompt.
2. If you're in your project environment, run:

```bash
pip freeze > requirements.txt
